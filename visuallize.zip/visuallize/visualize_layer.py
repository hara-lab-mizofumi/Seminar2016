from visualize_caffe import *
import os,sys,caffe

# Make sure caffe can be found
sys.path.append('/mnt/caffe/python/')


caffe_root='/mnt/caffe/'
os.chdir(caffe_root)

# Load model
#net = caffe.Net('/mnt/caffe/examples/mnist/lenet_train_test.prototxt',
#                '/mnt/caffe/examples/mnist/lenet_iter_10000.caffemodel',
#                caffe.TEST)

net = caffe.Net(caffe_root + 'examples/mnist/lenet_train_test.prototxt',
                caffe_root + 'examples/mnist/lenet_iter_10000.caffemodel',
                caffe.TEST)


visualize_weights(net, 'conv1', filename='/mnt/visuallize/conv1.png')
visualize_weights(net, 'conv2', filename='/mnt/visuallize/conv2.png')
#visualize_weights(net, 'pool1', filename='/mnt/visuallize/pool1.png')
#visualize_weights(net, 'pool2', filename='/mnt/visuallize/pool2.png')
