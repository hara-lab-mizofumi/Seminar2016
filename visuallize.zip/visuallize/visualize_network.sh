##Require
# apt-get install python-pydot
# pip install pydot

/mnt/caffe/python/draw_net.py /mnt/caffe/examples/mnist/lenet_train_test.prototxt /mnt/visuallize/network.png
