#!/bin/sh

set -e

display_help() {
    echo "Usage: $0 Arg1 Arg2" >&2
    echo
    echo "Arg 1 : raw_scale size"
    echo "Arg 2 : image path"
    #echo "Arg 3 : label data path"
    # echo some stuff here for the -a or --add-options 
    exit 1
}

while :
do
    case "$1" in
    	-h | --help)
		display_help
		exit 0
		;;
    esac
	break
done

if [ $# -ne 2 ]; then
    display_help
    exit 0
fi

#cd /mnt/caffe/python
cd /mnt/number_detect
echo "classify executing..."
pwd
python lenet_classify.py ${2} /mnt/number_detect/result.npy --model_def /mnt/caffe/examples/mnist/lenet.prototxt --pretrained_model /mnt/caffe/examples/mnist/lenet_iter_10000.caffemodel
echo "classify execute complate"

python show_mnist_result.py result.npy

cd /mnt/number_detect/
#python result.py ${3} /mnt/number_detect/result.npy

